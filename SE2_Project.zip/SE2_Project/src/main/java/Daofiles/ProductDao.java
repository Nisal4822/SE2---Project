package Daofiles;

import java.sql.*;
import java.util.*;

import Modelfiles.Cart;
import Modelfiles.Product;

public class ProductDao {
	private Connection con;

	private String query;
    private PreparedStatement pst;
    private ResultSet rs;
    

	public ProductDao(Connection con) {
		super();
		this.con = con;
	}
	
	
	public List<Product> getAllProducts() {
        List<Product> book = new ArrayList<>();
        try {

            query = "select * from project_schema.products_table";
            pst = this.con.prepareStatement(query);
            rs = pst.executeQuery();

            while (rs.next()) {
            	Product row = new Product();
                row.setId(rs.getInt("p_id"));
                row.setName(rs.getString("p_name"));
                row.setCategory(rs.getString("p_category"));
                row.setPrice(rs.getDouble("p_price"));
                row.setImage(rs.getString("p_image"));

                book.add(row);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return book;
    }
	
	
	// For Stationaries
	public List<Product> getStationaryProducts() {
        List<Product> book = new ArrayList<>();
        try {

            query = "select * from project_schema.products_table where p_id BETWEEN 1 AND 6";
            pst = this.con.prepareStatement(query);
            rs = pst.executeQuery();

            while (rs.next()) {
            	Product row = new Product();
                row.setId(rs.getInt("p_id"));
                row.setName(rs.getString("p_name"));
                row.setCategory(rs.getString("p_category"));
                row.setPrice(rs.getDouble("p_price"));
                row.setImage(rs.getString("p_image"));

                book.add(row);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return book;
    }
	
	
	
	// For Bakery items
		public List<Product> getBakeryProducts() {
	        List<Product> book = new ArrayList<>();
	        try {

	            query = "select * from project_schema.products_table where p_id BETWEEN 13 AND 18";
	            pst = this.con.prepareStatement(query);
	            rs = pst.executeQuery();

	            while (rs.next()) {
	            	Product row = new Product();
	                row.setId(rs.getInt("p_id"));
	                row.setName(rs.getString("p_name"));
	                row.setCategory(rs.getString("p_category"));
	                row.setPrice(rs.getDouble("p_price"));
	                row.setImage(rs.getString("p_image"));

	                book.add(row);
	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	            System.out.println(e.getMessage());
	        }
	        return book;
	    }
		
		
		
		// For Beverages
				public List<Product> getBeverageProducts() {
			        List<Product> book = new ArrayList<>();
			        try {

			            query = "select * from project_schema.products_table where p_id BETWEEN 7 AND 12";
			            pst = this.con.prepareStatement(query);
			            rs = pst.executeQuery();

			            while (rs.next()) {
			            	Product row = new Product();
			                row.setId(rs.getInt("p_id"));
			                row.setName(rs.getString("p_name"));
			                row.setCategory(rs.getString("p_category"));
			                row.setPrice(rs.getDouble("p_price"));
			                row.setImage(rs.getString("p_image"));

			                book.add(row);
			            }

			        } catch (SQLException e) {
			            e.printStackTrace();
			            System.out.println(e.getMessage());
			        }
			        return book;
			    }
				
				
				
				// For Fruits and Vegetables
				public List<Product> getFandVProducts() {
			        List<Product> book = new ArrayList<>();
			        try {

			            query = "select * from project_schema.products_table where p_id BETWEEN 19 AND 24";
			            pst = this.con.prepareStatement(query);
			            rs = pst.executeQuery();

			            while (rs.next()) {
			            	Product row = new Product();
			                row.setId(rs.getInt("p_id"));
			                row.setName(rs.getString("p_name"));
			                row.setCategory(rs.getString("p_category"));
			                row.setPrice(rs.getDouble("p_price"));
			                row.setImage(rs.getString("p_image"));

			                book.add(row);
			            }

			        } catch (SQLException e) {
			            e.printStackTrace();
			            System.out.println(e.getMessage());
			        }
			        return book;
			    }
				
		
	
	
	 public Product getSingleProduct(int id) {
		 Product row = null;
	        try {
	            query = "select * from products_table where p_id=? ";

	            pst = this.con.prepareStatement(query);
	            pst.setInt(1, id);
	            ResultSet rs = pst.executeQuery();

	            while (rs.next()) {
	            	row = new Product();
	                row.setId(rs.getInt("p_id"));
	                row.setName(rs.getString("p_name"));
	                row.setCategory(rs.getString("p_category"));
	                row.setPrice(rs.getDouble("p_price"));
	                row.setImage(rs.getString("p_image"));
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            System.out.println(e.getMessage());
	        }

	        return row;
	    }
	
	public double getTotalCartPrice(ArrayList<Cart> cartList) {
        double sum = 0;
        try {
            if (cartList.size() > 0) {
                for (Cart item : cartList) {
                    query = "select p_price from products_table where p_id=?";
                    pst = this.con.prepareStatement(query);
                    pst.setInt(1, item.getId());
                    rs = pst.executeQuery();
                    while (rs.next()) {
                        sum+=rs.getDouble("p_price")*item.getQuantity();
                    }

                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return sum;
    }

    
    public List<Cart> getCartProducts(ArrayList<Cart> cartList) {
        List<Cart> book = new ArrayList<>();
        try {
            if (cartList.size() > 0) {
                for (Cart item : cartList) {
                    query = "select * from products_table where p_id=?";
                    pst = this.con.prepareStatement(query);
                    pst.setInt(1, item.getId());
                    rs = pst.executeQuery();
                    while (rs.next()) {
                        Cart row = new Cart();
                        row.setId(rs.getInt("p_id"));
                        row.setName(rs.getString("p_name"));
                        row.setCategory(rs.getString("p_category"));
                        row.setPrice(rs.getDouble("p_price")*item.getQuantity());
                        row.setQuantity(item.getQuantity());
                        book.add(row);
                    }

                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return book;
    }
}
