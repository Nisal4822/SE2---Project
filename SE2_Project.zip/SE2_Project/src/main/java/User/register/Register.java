package User.register;

public class Register {
	
	private String firstName;
    private String lastName;
    private String mobilenum;
    private String useremail;
    private String paypalemail;
    private String paypalpswd;
    private String userpswd;
    
    public void setFirstname(String Firstname) {
        this.firstName = Firstname;
    }
    public String getFirstname() {
        return firstName;
    }
    
    
    public void setLastname(String Lastname) {
        this.lastName = Lastname;
    }
    public String getLastname() {
        return lastName;
    }
    
    
    public void setMobilenumber(String Mobilenumber) {
        this.mobilenum = Mobilenumber;
    }
    public String getMobilenumber() {
        return mobilenum;
    }
    
    
    public void setUseremail(String Useremail) {
        this.useremail = Useremail;
    }
    public String getUseremail() {
        return useremail;
    }
    
    
    public void setPaypalemail(String Paypalemail) {
        this.paypalemail = Paypalemail;
    }
    public String getPaypalemail() {
        return paypalemail;
    }
    
    
    public void setPaypalpswd(String Paypalpswd) {
        this.paypalpswd = Paypalpswd;
    }
    public String getPaypalpswd() {
        return paypalpswd;
    }
    
    
    public void setUserpswd(String Userpswd) {
        this.userpswd = Userpswd;
    }
    public String getUserpswd() {
        return userpswd;
    }

}
