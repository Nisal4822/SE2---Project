package User.register;

import java.io.PrintWriter;
import jakarta.servlet.RequestDispatcher;
//import jakarta.servlet.*;
//import jakarta.servlet.http.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
//import jakarta.servlet.annotation.*;
import java.io.IOException;


@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public Register_Dao reg;  // Object for the Register_Dao.java class
	
	public void init() {
		reg = new Register_Dao();
	}
	

    public RegisterServlet() {
    	super();
    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		/*RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/Registerpage.jsp");
		dispatcher.forward(request, response);*/
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/Registerpage.jsp");
		dispatcher.forward(request, response);
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
       try {
    	   String firstname = request.getParameter("firstname");
           String Lastname = request.getParameter("Lastname");
           String Mobilenumber = request.getParameter("Mobilenumber");
           String Useremail = request.getParameter("Useremail");
           String Paypalemail = request.getParameter("Paypalemail");
           String Paypalpswd = request.getParameter("Paypalpswd");
           String Userpswd = request.getParameter("Userpswd");

           Register reg1 = new Register();
           reg1.setFirstname(firstname);
           reg1.setLastname(Lastname);
           reg1.setMobilenumber(Mobilenumber);
           reg1.setUseremail(Useremail);
           reg1.setPaypalemail(Paypalemail);
           reg1.setPaypalpswd(Paypalpswd);
           reg1.setUserpswd(Userpswd);
        	PrintWriter pw = response.getWriter();
        	System.out.print(firstname);
    	  // pw.println(" "+firstName+" "+lastName+" "+mobilenum+" "+useremail+" "+paypalemail+" "+paypalpswd+" "+userpswd);*/
    	   reg.registerUsers(reg1);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
