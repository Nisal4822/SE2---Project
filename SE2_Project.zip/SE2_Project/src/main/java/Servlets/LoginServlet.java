package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import DBConnection.DbCon;
import Daofiles.*;
import Modelfiles.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	/*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		/*RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/Registerpage.jsp");
		dispatcher.forward(request, response);*/
		
		/*RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/Login.jsp");
		dispatcher.forward(request, response);
	}*/
	
	
	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {
			String Useremail = request.getParameter("Useremail");
			String Userpswd = request.getParameter("Userpswd");
			
			

			UserDao udao = new UserDao(DbCon.getConnection());
			User user = udao.userLogin(Useremail, Userpswd);
			if (user != null) {
				request.getSession().setAttribute("auth", user);
//				System.out.print("user logged in");
				response.sendRedirect("index.jsp");
			} else {
				out.println("You haven't registered");
			}

		} catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
	}
}
